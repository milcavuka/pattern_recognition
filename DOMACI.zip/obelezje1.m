function o = obelezje1(Vx, Vy)
% Ova funkcija prikazuje obelezje 1, koje je zapravo razlika maksimuma i minimuma po x osi 
    o = mean(Vx)- mean(Vy);
%    i = 1:length(Vx);
%    o = sum(Vx.*i)/sum(Vx);
end
