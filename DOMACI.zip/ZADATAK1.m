clc
close all
clear all

load('PO_slova.mat')
N = 119;
A = a(1:N);
B = b(1:N);
C = c(1:N);
Z = z(1:N);
E = e(1:N);
G = g(1:N);
P = p(1:N);
I = i(1:N);
M = m(1:N);
W = w(1:N);


A1 = A{3}; B1 = B{3}; C1 = C{3}; Z1 = Z{3}; E1 = E{3}; G1 = G{3}; P1 = P{3}; I1 = I{3};
M1 = M{3}; W1 = W{3};


Ax = A1(1,:); Ay = A1(2,:);
Axp = cumsum(Ax); Ayp = cumsum(Ay);

Bx = B1(1,:); By =B1(2,:);
Bxp = cumsum(Bx); Byp = cumsum(By);

Cx = C1(1,:); Cy = C1(2,:);
Cxp = cumsum(Cx); Cyp = cumsum(Cy);

Zx = Z1(1,:); Zy = Z1(2,:);
Zxp = cumsum(Zx); Zyp = cumsum(Zy);

Ex = E1(1,:); Ey = E1(2,:);
Exp = cumsum(Ex); Eyp = cumsum(Ey);

Gx = G1(1,:); Gy = G1(2,:);
Gxp = cumsum(Gx); Gyp = cumsum(Gy);

Px = P1(1,:); Py = P1(2,:);
Pxp = cumsum(Px); Pyp = cumsum(Py);

Ix = I1(1,:); Iy = I1(2,:);
Ixp = cumsum(Ix); Iyp = cumsum(Iy);

Mx = M1(1,:); My = M1(2,:);
Mxp = cumsum(Mx); Myp = cumsum(My);

Wx = W1(1,:); Wy = W1(2,:);
Wxp = cumsum(Wx); Wyp = cumsum(Wy);

figure()
    subplot(2,2,[1 3])
    scatter(Axp,Ayp);
    xlabel('Polozaj x'); ylabel('Polozaj y')
    title('Slovo A')
    subplot(2,2,2)
    plot(1:length(Ax),Ax,'Color',[0 0 0])
    xlabel('kT'); ylabel('Vx')
    title('Brzina Vx')
    subplot(2,2,4)
    plot(1:length(Ay),Ay,'Color',[0 0 0])
    xlabel('kT'); ylabel('Vy')
    title('Brzina Vy')

figure()
    subplot(2,2,[1 3])
    scatter(Bxp,Byp);
    xlabel('Polozaj x'); ylabel('Polozaj y')
    title('Slovo B')
    subplot(2,2,2)
    plot(1:length(Bx),Bx,'Color',[0 0 0])
    xlabel('kT'); ylabel('Vx')
    title('Brzina Vx')
    subplot(2,2,4)
    plot(1:length(By),By,'Color',[0 0 0])
    xlabel('kT'); ylabel('Vy')
    title('Brzina Vy')

figure()
    subplot(2,2,[1 3])
    scatter(Cxp,Cyp);
    xlabel('Polozaj x'); ylabel('Polozaj y')
    title('Slovo C')
    subplot(2,2,2)
    plot(1:length(Cx),Cx,'Color',[0 0 0])
    xlabel('kT'); ylabel('Vx')
    title('Brzina Vx')
    subplot(2,2,4)
    plot(1:length(Cy),Cy,'Color',[0 0 0])
    xlabel('kT'); ylabel('Vy')
    title('Brzina Vy')

figure()
    subplot(2,2,[1 3])
    scatter(Zxp,Zyp);
    xlabel('Polozaj x'); ylabel('Polozaj y')
    title('Slovo Z')
    subplot(2,2,2)
    plot(1:length(Zx),Zx,'Color',[0 0 0])
    xlabel('kT'); ylabel('Vx')
    title('Brzina Vx')
    subplot(2,2,4)
    plot(1:length(Zy),Zy,'Color',[0 0 0])
    xlabel('kT'); ylabel('Vy')
    title('Brzina Vy')
    
    figure()
    subplot(2,2,[1 3])
    scatter(Exp,Eyp);
    xlabel('Polozaj x'); ylabel('Polozaj y')
    title('Slovo E')
    subplot(2,2,2)
    plot(1:length(Ex),Ex,'Color',[0 0 0])
    xlabel('kT'); ylabel('Vx')
    title('Brzina Vx')
    subplot(2,2,4)
    plot(1:length(Ey),Ey,'Color',[0 0 0])
    xlabel('kT'); ylabel('Vy')
    title('Brzina Vy')
    
    
    figure()
    subplot(2,2,[1 3])
    scatter(Gxp,Gyp);
    xlabel('Polozaj x'); ylabel('Polozaj y')
    title('Slovo G')
    subplot(2,2,2)
    plot(1:length(Gx),Gx,'Color',[0 0 0])
    xlabel('kT'); ylabel('Vx')
    title('Brzina Vx')
    subplot(2,2,4)
    plot(1:length(Gy),Gy,'Color',[0 0 0])
    xlabel('kT'); ylabel('Vy')
    title('Brzina Vy')
    
    figure()
    subplot(2,2,[1 3])
    scatter(Pxp,Pyp);
    xlabel('Polozaj x'); ylabel('Polozaj y')
    title('Slovo P')
    subplot(2,2,2)
    plot(1:length(Px),Px,'Color',[0 0 0])
    xlabel('kT'); ylabel('Vx')
    title('Brzina Vx')
    subplot(2,2,4)
    plot(1:length(Py),Py,'Color',[0 0 0])
    xlabel('kT'); ylabel('Vy')
    title('Brzina Vy')
    
    figure()
    subplot(2,2,[1 3])
    scatter(Ixp,Iyp);
    xlabel('Polozaj x'); ylabel('Polozaj y')
    title('Slovo I')
    subplot(2,2,2)
    plot(1:length(Ix),Ix,'Color',[0 0 0])
    xlabel('kT'); ylabel('Vx')
    title('Brzina Vx')
    subplot(2,2,4)
    plot(1:length(Iy),Iy,'Color',[0 0 0])
    xlabel('kT'); ylabel('Vy')
    title('Brzina Vy')
    
    figure()
    subplot(2,2,[1 3])
    scatter(Mxp,Myp);
    xlabel('Polozaj x'); ylabel('Polozaj y')
    title('Slovo M')
    subplot(2,2,2)
    plot(1:length(Mx),Mx,'Color',[0 0 0])
    xlabel('kT'); ylabel('Vx')
    title('Brzina Vx')
    subplot(2,2,4)
    plot(1:length(My),My,'Color',[0 0 0])
    xlabel('kT'); ylabel('Vy')
    title('Brzina Vy')
    
    figure()
    subplot(2,2,[1 3])
    scatter(Wxp,Wyp);
    xlabel('Polozaj x'); ylabel('Polozaj y')
    title('Slovo W')
    subplot(2,2,2)
    plot(1:length(Wx),Wx,'Color',[0 0 0])
    xlabel('WT'); ylabel('Vx')
    title('Brzina Vx')
    subplot(2,2,4)
    plot(1:length(Wy),Wy,'Color',[0 0 0])
    xlabel('WT'); ylabel('Vy')
    title('Brzina Vy')

Aobelezje = zeros(2,N);
Aobelezje = zeros(2,N);
Aobelezje = zeros(2,N);

for i = 1:N
    A_trenutno = A{i};
    Aobelezje(1,i) = obelezje1(A_trenutno(1,:),A_trenutno(2,:));
    Aobelezje(2,i) = obelezje2(A_trenutno(1,:),A_trenutno(2,:));
end

for i = 1:N
    B_trenutno = B{i};
    Bobelezje(1,i) = obelezje1(B_trenutno(1,:),B_trenutno(2,:));
    Bobelezje(2,i) = obelezje2(B_trenutno(1,:),B_trenutno(2,:));
end

for i = 1:N
    C_trenutno = C{i};
    Cobelezje(1,i) = obelezje1(C_trenutno(1,:),C_trenutno(2,:));
    Cobelezje(2,i) = obelezje2(C_trenutno(1,:),C_trenutno(2,:));
end

for i = 1:N
    Z_trenutno = Z{i};
    Zobelezje(1,i) = obelezje1(Z_trenutno(1,:),Z_trenutno(2,:));
    Zobelezje(2,i) = obelezje2(Z_trenutno(1,:),Z_trenutno(2,:));
end

for i = 1:N
    E_trenutno = E{i};
    Eobelezje(1,i) = obelezje1(E_trenutno(1,:),E_trenutno(2,:));
    Eobelezje(2,i) = obelezje2(E_trenutno(1,:),E_trenutno(2,:));
end

for i = 1:N
    G_trenutno = G{i};
    Gobelezje(1,i) = obelezje1(G_trenutno(1,:), G_trenutno(2,:));
    Gobelezje(2,i) = obelezje2(G_trenutno(1,:), G_trenutno(2,:));
end

for i = 1:N
    P_trenutno = P{i};
    Pobelezje(1,i) = obelezje1(P_trenutno(1,:),P_trenutno(2,:));
    Pobelezje(2,i) = obelezje2(P_trenutno(1,:),P_trenutno(2,:));
end

for i = 1:N
    I_trenutno = I{i};
    Iobelezje(1,i) = obelezje1(I_trenutno(1,:),I_trenutno(2,:));
    Iobelezje(2,i) = obelezje2(I_trenutno(1,:),I_trenutno(2,:));
end

for i = 1:N
    M_trenutno = M{i};
    Mobelezje(1,i) = obelezje1(M_trenutno(1,:),M_trenutno(2,:));
    Mobelezje(2,i) = obelezje2(M_trenutno(1,:),M_trenutno(2,:));
end

for i = 1:N
    W_trenutno = W{i};
    Wobelezje(1,i) = obelezje1(W_trenutno(1,:),W_trenutno(2,:));
    Wobelezje(2,i) = obelezje2(W_trenutno(1,:),W_trenutno(2,:));
end


figure()
    hold all
    plot(Aobelezje(1,:),Aobelezje(2,:),'x');
    plot(Bobelezje(1,:),Bobelezje(2,:),'x');
    plot(Cobelezje(1,:),Cobelezje(2,:),'kx');
    plot(Zobelezje(1,:),Zobelezje(2,:),'x');
    plot(Eobelezje(1,:),Eobelezje(2,:),'x');
    plot(Gobelezje(1,:),Gobelezje(2,:),'x');
    plot(Pobelezje(1,:),Pobelezje(2,:),'gx');
    plot(Iobelezje(1,:),Iobelezje(2,:),'x');
    plot(Mobelezje(1,:),Mobelezje(2,:),'o');
    plot(Wobelezje(1,:),Wobelezje(2,:),'x');
    
    xlabel('x1'); ylabel('x2')
    legend('K1','K2','K3','K4', 'K5', 'K6', 'K7', 'K8', 'K9', 'K10')

S1 = cov(Aobelezje'); S2 = cov(Bobelezje'); S3 = cov(Cobelezje');
S4 = cov(Zobelezje'); S5 = cov(Eobelezje'); S6 = cov(Gobelezje'); 
S7 = cov(Pobelezje'); S8 = cov(Iobelezje'); S9 = cov(Mobelezje'); 
S10 = cov(Wobelezje');



M1 = mean(Aobelezje'); M2 = mean(Bobelezje'); M3 = mean(Cobelezje');
M4 = mean(Zobelezje');M5 = mean(Eobelezje');M6 = mean(Gobelezje');
M7 = mean(Pobelezje');M8 = mean(Iobelezje');M9 = mean(Mobelezje');
M10 = mean(Wobelezje');



%% Klasifikaciija

X = [Aobelezje Bobelezje Cobelezje Zobelezje Eobelezje Gobelezje Pobelezje Iobelezje Mobelezje Wobelezje];
Y_true = [ones(1,length(Aobelezje)) 2*ones(1,length(Aobelezje)) 3*ones(1,length(Aobelezje)) 4*ones(1,length(Aobelezje)) 5*ones(1,length(Aobelezje)) 6*ones(1,length(Aobelezje)) 7*ones(1,length(Aobelezje)) 8*ones(1,length(Aobelezje)) 9*ones(1,length(Aobelezje)) 10*ones(1,length(Aobelezje))];
Y_predikcija = zeros(1,length(X));

for i = 1:length(X)
    X_trenutno = X(:,i);
    f1 = fgv(X_trenutno, M1', S1);
     f2 = fgv(X_trenutno, M2', S2);
      f3 = fgv(X_trenutno, M3', S3);
       f4 = fgv(X_trenutno, M4', S4);
        f5 = fgv(X_trenutno, M5', S5);
         f6 = fgv(X_trenutno, M6', S6);
          f7 = fgv(X_trenutno, M7', S7);
           f8 = fgv(X_trenutno, M8', S8);
            f9 = fgv(X_trenutno, M9', S9);
             f10 = fgv(X_trenutno, M10', S10);
             
    f = [f1 f2 f3 f4 f5 f6 f7 f8 f9 f10];
    [m , ind] = max(f);
    
    Y_predikcija(i) = ind;
end

C = confusionmat(Y_true,Y_predikcija)

%%

klasa1 = Zobelezje;
klasa2 = Pobelezje;

Mnovo1 = M4;
Mnovo2 = M7;
Snovo1 = S4;
Snovo2 = S7;

X_novo = [klasa1 klasa2];
Y_true = [ones(1, length(klasa1)), 2*ones(1, length(klasa2))];
Y_pred = zeros(1, length(X_novo));

figure
    scatter(klasa1(1,:),klasa1(2,:),'ro'); 
    hold all
    scatter(klasa2(1,:),klasa2(2,:),'bx');
    xlabel('x1'); ylabel('x2')
    legend('Z','P')
    title('Dve separabilne klase')
    
x = -0.1:0.001:0.5;
y = -1.5:0.001:2;
e = zeros(length(x), length(y));
for i = 1:length(x)
    for j = 1:length(y)
        X_tren = [x(i) y(j)]';
        e1 = sqrt(sum((X_tren-Mnovo1').^2));
        e2 = sqrt(sum((X_tren-Mnovo2').^2));
     
        e(i,j) = e1 - e2;
    end   
end


figure
    scatter(klasa1(1,:),klasa1(2,:),'ro'); 
    hold all
    scatter(klasa2(1,:),klasa2(2,:),'bx');
    xlabel('x1'); ylabel('x2')
    title('Klasifikator distance')
    contour(x,y,e',[0 0],'g','LineWidth',1.2)
    legend('Z','P', 'klasifikaciona linija')
    