clc
close all
clear all

N = 500;
M1 = [-2 -2]';
M2 = [3,3]';
M3 = [8,0]';

S1 = [2 -0.5; -0.5 2];
S2 = [0.9 0.7; 0.7 0.9];
S3 = [1 -0.5; -0.5 1];
 
K1 = mvnrnd(M1,S1,N)';
K2 = mvnrnd(M2,S2,N)';
K3 = mvnrnd(M3,S3,N)';

figure
    scatter(K1(1,:),K1(2,:),'ro'); 
    hold all
    scatter(K2(1,:),K2(2,:),'bx');
    scatter(K3(1,:),K3(2,:),'gx');
    xlabel('x1'); ylabel('x2')
    legend('K1','K2', 'K3')
    title('Klase')
    
%% Metoda resupstitucije
K12 = [K1 K2];
M12_est = mean(K12,2);
M3_est = mean(K3,2);
S12_est = cov(K12');
S3_est = cov(K3');

s = 0:1e-3:1;
v0_opt_s = [];
Neps_s = [];

for k = 1:length(s)
    v = (s(k)*S12_est + (1-s(k))*S3_est)^( -1)*(M3_est-M12_est);
    v0 = [];
    Neps = [];
    Y12 = v'*K12;
    Y3 = v'*K3;
    Y = [Y12 Y3]; Y = sort(Y);
    for j = 1:length(Y)-1
        v0(j) = -(Y(j)+Y(j+1))/2;
        Neps(j) = 0;

        for i = 1:length(Y12)
            if (Y12(i) > -v0(j))
                Neps(j) = Neps(j) +1;
            end
        end
        for i = 1:length(Y3)
            if (Y3(i) < -v0(j))
                Neps(j) = Neps(j) +1;
            end
        end

    end
    [Neps_s(k), ind] = min(Neps);
    v0_opt_s(k) = v0(ind);

end
[Neps_opt, ind] = min(Neps_s);
v0_opt = v0_opt_s(ind);
s_opt = s(ind);

%% 

v_opt = (s_opt*S12_est+(1-s_opt)*S3_est)^(-1)*(M3_est-M12_est);
x11 = -8:0.1:12;
x21 = -(v0_opt+v_opt(1)*x11)/v_opt(2);

figure(2)
hold all
grid on
scatter(K12(1,:),K12(2,:),'bx')
scatter(K3(1,:),K3(2,:),'ro')
plot(x11,x21,'k--')
xlabel('x1'); ylabel('x2');
title('Klasifikacija prve dve klase od trece')  

Ytrue = [ones(1,N), 2*ones(1,N), 3*ones(1,N)];
Ypred = ones(1,3*N);

for i =1 :N
    
   Xtren = K3(:,i);
   if (v_opt' * Xtren + v0_opt) > 0
       Ypred(1000+i) = 3;
       
   end
    
end

%% Klasa 1 i 2

M1_est = mean(K1,2);
M2_est = mean(K2,2);
S1_est = cov(K2');
S2_est = cov(K3');

s = 0:1e-3:1;
v0_opt_s = [];
Neps_s = [];

for k = 1:length(s)
    v = (s(k)*S1_est + (1-s(k))*S2_est)^( -1)*(M2_est-M1_est);
    v0 = [];
    Neps = [];
    Y1 = v'*K1;
    Y2 = v'*K2;
    Y = [Y1 Y2]; Y = sort(Y);
    for j = 1:length(Y)-1
        v0(j) = -(Y(j)+Y(j+1))/2;
        Neps(j) = 0;

        for i = 1:N
            if (Y1(i) > -v0(j))
                Neps(j) = Neps(j) +1;
            end
            if (Y2(i) < -v0(j))
                Neps(j) = Neps(j) +1;
            end
        end

    end
    [Neps_s(k), ind] = min(Neps);
    v0_opt_s(k) = v0(ind);

end
[Neps_opt, ind] = min(Neps_s);
v0_opt = v0_opt_s(ind);
s_opt = s(ind);

%%  

v_opt = (s_opt*S1_est+(1-s_opt)*S2_est)^(-1)*(M2_est-M1_est);
x12 = -8:0.1:12;
x22 = -(v0_opt+v_opt(1)*x12)/v_opt(2);

figure(3)
scatter(K1(1,:),K1(2,:),'ro'); 
hold all
scatter(K2(1,:),K2(2,:),'bx');
scatter(K3(1,:),K3(2,:),'gx');
plot(x11,x21,'k--')
plot(x12,x22,'k--')
xlabel('x1'); ylabel('x2');
title('Sve tri klase klasterizovane')

X = [K1 K2];
for i =1 :2*N
    
   Xtren = X(:,i);
   if (v_opt' * Xtren + v0_opt) > 0
       Ypred(i) = 2;
   else
       Ypred(i) = 1;
   end
    
end

C = confusionmat(Ytrue,Ypred)

%% Linearni klasifikator

% Prvo razdvajamo prve dve klase od trece
X12 = [K1, K2];
X3 = K3;

U = [-1*ones(1,2*N) ones(1,N); -X12, X3];
G = ones(3*N,1); %gamma
W = (U*U')\U*G;

v0 = W(1); v1 = W(2); v2 = W(3);

x11 = -8:0.1:12;
x21 = -(v0+v1*x11)/v2;

figure(4)
scatter(K1(1,:),K1(2,:),'ro'); 
hold all
scatter(K2(1,:),K2(2,:),'bx');
scatter(K3(1,:),K3(2,:),'gx');
xlabel('x1'); ylabel('x2')
legend('K1','K2', 'K3', 'klasifikaciona linija')
plot(x11,x21,'c--')
title('Razdvajanje trece klase')

Ytrue = [ones(1,N), 2*ones(1,N), 3*ones(1,N)];
Ypred = ones(1,3*N);

for i =1 :N
    
   Xtren = K3(:,i);
   v_opt = [v1; v2];
   if (v_opt' * Xtren + v0) > 0
       Ypred(1000+i) = 3;
       
   end
    
end

% razdvajanje prve dve klase

X1 = [K1];
X2 = K2;

U = [-1*ones(1,N) ones(1,N); -X1, X2];
G = ones(2*N,1); %gamma
W = (U*U')\U*G;

v0 = W(1); v1 = W(2); v2 = W(3);

x12 = -8:0.1:12;
x22 = -(v0+v1*x11)/v2;

figure(5)
scatter(K1(1,:),K1(2,:),'ro'); 
hold all
scatter(K2(1,:),K2(2,:),'bx');
scatter(K3(1,:),K3(2,:),'gx');
xlabel('x1'); ylabel('x2')

plot(x11,x21,'c--')
plot(x12,x22,'c--')
title('Sve tri klase klasifkovane')
legend('K1','K2', 'K3', 'klas linija1', 'klas linija2')

v_opt = [v1; v2];
X = [K1 K2];
for i =1 :(2*N)
   
   Xtren = X(:,i);
   if (v_opt' * Xtren + v0) > 0
       Ypred(i) = 2;
   else
       Ypred(i) = 1;
   end
    
end

C = confusionmat(Ytrue,Ypred)


%% Gama vece za klasu 3

% Prvo razdvajamo prve dve klase od trece
X12 = [K1, K2];
X3 = K3;

U = [-1*ones(1,2*N) ones(1,N); -X12, X3];
G = [ones(2*N,1); 3* ones(N,1)]; %gamma
W = (U*U')\U*G;

v0 = W(1); v1 = W(2); v2 = W(3);

x11 = -8:0.1:12;
x21 = -(v0+v1*x11)/v2;

figure(6)
scatter(K1(1,:),K1(2,:),'ro'); 
hold all
scatter(K2(1,:),K2(2,:),'bx');
scatter(K3(1,:),K3(2,:),'gx');
xlabel('x1'); ylabel('x2')
legend('K1','K2', 'K3')
plot(x11,x21,'c--')
title('Razdvajanje trece klase')

Ytrue = [ones(1,N), 2*ones(1,N), 3*ones(1,N)];
Ypred = zeros(1,3*N);

for i =1 :N
    
   Xtren = K3(:,i);
   v_opt = [v1; v2];
   if (v_opt' * Xtren + v0) > 0
       Ypred(1000+i) = 3;
       
   end
    
end

% razdvajanje prve dve klase

X1 = [K1];
X2 = K2;

U = [-1*ones(1,N) ones(1,N); -X1, X2];
G = ones(2*N,1); %gamma
W = (U*U')\U*G;

v0 = W(1); v1 = W(2); v2 = W(3);

x12 = -8:0.1:12;
x22 = -(v0+v1*x11)/v2;

figure(7)
scatter(K1(1,:),K1(2,:),'ro'); 
hold all
scatter(K2(1,:),K2(2,:),'bx');
scatter(K3(1,:),K3(2,:),'gx');
xlabel('x1'); ylabel('x2')

plot(x11,x21,'c--')
plot(x12,x22,'c--')
title('Sve tri klase klasterizovane')
legend('K1','K2', 'K3', 'klas_linija1', 'klas_linija2')

v_opt = [v1; v2];
X = [K1 K2];
for i =1 :2*N
   
   Xtren = X(:,i);
   if (v_opt' * Xtren + v0) > 0
       Ypred(i) = 2;
   else
       Ypred(i) = 1;
   end
    
end

C = confusionmat(Ytrue,Ypred)

%% kvadratna klasifikacija


N = 500;
X = zeros(2,N);
Y = zeros(2,N);
ro_1   = rand(1,N);
teta_1 = rand(1,N)*2*pi;
ro_2   = rand(1,N)+3;
teta_2 = rand(1,N)*2*pi;

X(1,:) = ro_1.*cos(teta_1);
X(2,:) = ro_1.*sin(teta_1);

Y(1,:) = ro_2.*cos(teta_2);
Y(2,:) = ro_2.*sin(teta_2);

figure(8)
hold all
grid on
scatter(X(1,:),X(2,:),'bx')
scatter(Y(1,:),Y(2,:),'ro')
title('Nelinearlno seprabilne klase')
legend('Klasa 1', 'Klasa 2')

U = [-1*ones(1,N) ones(1,N); -X, Y; -X(1,:).^2 Y(1,:).^2; ...
    -X(2,:).^2 Y(2,:).^2; -2*X(1,:).*X(2,:) 2*Y(1,:).*Y(2,:)];
G = ones(2*N,1); %gamma
W = (U*U')\U*G;

v0 = W(1); v1 = W(2); v2 = W(3); v3 = W(4); v4 = W(5); v5 = W(6);

x1 = -5:0.1:5;
x2 = -5:0.1:5;
h = zeros(length(x1), length(x2));

for j = 1:length(x2)
    for i = 1:length(x1)
        h(i,j) = v0+v1*x1(i)+v2*x2(j)+v3*x1(i).^2+v4*x2(j).^2+2*v5*x2(j).*x1(i);
    end
end

figure(9)
hold all
grid on
scatter(X(1,:),X(2,:),'bx')
scatter(Y(1,:),Y(2,:),'ro')
contour(x1,x2,h,[0 0], 'k--')
title('Kvadratni klasifikator')
legend('Klasa 1', 'Klasa 2', 'klasifikaciona linija')


