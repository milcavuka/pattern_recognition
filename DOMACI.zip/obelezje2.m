function o = obelezje2(Vx,Vy)
% Ova funkcija prikazuje obelezje 2, koje je zapravo razlika maksimuma i minimuma po y osi 
     o = var(Vx) -var(Vy);
%      i = 1:length(Vy);
%      o = sum(i .* Vy )/ sum(Vy);
end