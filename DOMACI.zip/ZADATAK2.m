clear
close all
clc

N = 500; % Odbirci svake od klasa
M1 = [4 4]'; S1 = [2 -0.5; -0.5 2];
M2 = [4 8]'; S2 = [0.9 0.7; 0.7 0.9];
M3 = [8 6]'; S3 = [1 -0.5; -0.5 1];
M4 = [8 3]'; S4 = [1 0.6; 0.6 1];

K11 = mvnrnd(M1,S1,N)';
K12 = mvnrnd(M2,S2,N)';
K21 = mvnrnd(M3,S3,N)';
K22 = mvnrnd(M4,S4,N)';


pom = rand(1,N);
K1 = (pom<=0.6).*K11+(pom>0.6).*K12;
K2 = (pom<=0.3).*K21+(pom>0.3).*K22;

figure
    scatter(K1(1,:),K1(2,:),'ro'); 
    hold all
    scatter(K2(1,:),K2(2,:),'bx');
    xlabel('x1'); ylabel('x2')
    legend('K1','K2')
    title ('Klasa 1 i 2')
    
x = -2:0.1:12;
y = -2:0.1:12;
f1 = zeros(length(x),length(y)); % Fgv klase K1
f2 = f1; % FGV klase K2

c1 = 1/(2*pi*det(S1)^0.5); % Konstante koje idu uz svaku fgv
c2 = 1/(2*pi*det(S2)^0.5);
c3 = 1/(2*pi*det(S3)^0.5);
c4 = 1/(2*pi*det(S4)^0.5);

for i = 1:length(x)
    for j = 1:length(y)
        X = [x(i),y(j)]';
        f11 = c1*exp(-0.5*(X-M1)'*inv(S1)*(X-M1));
        f12 = c2*exp(-0.5*(X-M2)'*inv(S2)*(X-M2));% Funkcije gustine verovatnoce
        f21 = c3*exp(-0.5*(X-M3)'*inv(S3)*(X-M3));
        f22 = c4*exp(-0.5*(X-M4)'*inv(S4)*(X-M4));
        f1(i,j) = 0.6*f11 + 0.4*f12;
        f2(i,j) = 0.3*f21 + 0.7*f22; % Pretpostavili smo da su 0.6 i 0.4
        
     
    end
end

figure
subplot(2,1,1)
surface(x,y,f1)
subplot(2,1,2)
hist3(K1')
title('Klasa 1')

figure
subplot(2,1,1)
surface(x,y,f1)
subplot(2,1,2)
hist3(K1')
title('Klasa 2')

figure
subplot(2,1,1)
surface(x,y,f1)
hold on
surface(x,y,f2)
subplot(2,1,2)
hist3(K1')
hold on 
hist3(K2')
title('Klasa 1 i 2')


h = -log(f1./f2);  %Diskriminaciona kriva

figure
    scatter(K1(1,:),K1(2,:),'ro'); % Ne zelimo da interpolira nesto izmedju
    hold all
    scatter(K2(1,:),K2(2,:),'bx');
    contour(x,y,h',[0 0],'g','LineWidth',1.2)
    xlabel('x1'); ylabel('x2')
    legend('K1','K2')
    title('Bajesov klasifikator minimalne greške')
    
%% Odredjivanje gresaka
Xs = [K1,K2];
Y_true = [ones(1,N), 2*ones(1,N)]; % Kojoj klasi on zaista pripada
Y_pred = zeros(1,2*N);

for i = 1:length(Xs)
    X = Xs(:,i);
    f11 = c1*exp(-0.5*(X-M1)'*inv(S1)*(X-M1));
    f12 = c2*exp(-0.5*(X-M2)'*inv(S2)*(X-M2));% Funkcije gustine verovatnoce
    f21 = c3*exp(-0.5*(X-M3)'*inv(S3)*(X-M3));
    f22 = c4*exp(-0.5*(X-M4)'*inv(S4)*(X-M4));
    f1 = 0.6*f11 + 0.4*f12;
    f2 = 0.3*f21 + 0.7*f22;
    if (f1>f2)
        Y_pred(i) = 1;
    else
        Y_pred(i) = 2;
    end
end

C = confusionmat(Y_true,Y_pred);
disp(C) % Prvi element su tacne vrednosti, a drugi ono sto smo procenili
e1 = C(1,2)/sum(C(1,:));
e2 = C(2,1)/sum(C(2,:));
disp('Greska prve vrste: ');
disp(e1);
disp('Greska druge vrste: ');
disp(e2);

% Teorijski pristup
e1 = 0; e2 = 0;
for i = 1:length(x)
    for j = 1:length(y)
        X = [x(i),y(j)]';
        f11 = c1*exp(-0.5*(X-M1)'*inv(S1)*(X-M1));
        f12 = c2*exp(-0.5*(X-M2)'*inv(S2)*(X-M2));% Funkcije gustine verovatnoce
        f21 = c3*exp(-0.5*(X-M3)'*inv(S3)*(X-M3));
        f22 = c4*exp(-0.5*(X-M4)'*inv(S4)*(X-M4));
        f1(i,j) = 0.6*f11 + 0.4*f12;
        f2(i,j) = 0.3*f21 + 0.7*f22;
        h = -log(f1(i,j)/f2(i,j));
        if (h > 0) % ako je vece od 0, pripada klasi 2
            e1 = e1 + f1(i,j)*0.1*0.1;
        else
            e2 = e2 + f2(i,j)*0.1*0.1;
        end
    end
end

disp('Greska prve vrste: ');
disp(e1);
disp('Greska druge vrste: ');
disp(e2);    
    


c11 = 0;
c22 = 0;
c12 = 0.1;
c21 = 1;

h = -log(f1./f2); 
T = -log((c22 - c12)/(c11 - c21));

figure
    scatter(K1(1,:),K1(2,:),'ro'); % Ne zelimo da interpolira nesto izmedju
    hold all
    scatter(K2(1,:),K2(2,:),'bx');
    contour(x,y,h',[0 0],'g','LineWidth',1.2)
    contour(x,y,h',[T T],'y','LineWidth',1.2)
    xlabel('x1'); ylabel('x2')
    legend('K1','K2', 'bajes', 'minimalna cena')
    title('Klasifikator minimalne cene')
    
    
%% Nojman - Pirsonov test

brojac = 0;
for mi = 0.01:0.01:10
    brojac = brojac+1;
    eps2(brojac) = 0;
    for i = 1:length(x)-1
        for j = 1:length(y)-1
            if(h(i,j) <= -log(mi))
                eps2(brojac) = eps2(brojac) + 0.1*0.1*(f2(i,j)+f2(i+1,j)+f2(i,j+1)+f2(i+1,j+1))/4;
                % Ne moramo raditi ovo usrednjavanje, ali 
                % Ako vec gledamo da se krecemo po kvadraticima, ima smisla usrednjiti
            end
        end
    end
end


figure()
    plot(0.01:0.01:10,eps2,"Color",[0 0 0])
    xlabel('\mu'); ylabel('\epsilon_2');
    title('Zavisnost \epsilon_2 od \mu')    


eps2_limit = 0.2;
index = find(eps2 <= eps2_limit,1);
mi = 0.01:0.01:10;
mi = mi(index);
    
    
figure
    scatter(K1(1,:),K1(2,:),'ro'); % Ne zelimo da interpolira nesto izmedju
    hold all
    scatter(K2(1,:),K2(2,:),'bx');
    contour(x,y,h',[0 0],'g','LineWidth',1.2)
    contour(x,y,h',[T T],'y','LineWidth',1.2)
    contour(x,y,h',[-log(mi) -log(mi)],'k','LineWidth',1.2)
    xlabel('x1'); ylabel('x2')
    legend('K1','K2', 'klasifikaciona linija - bajes', 'minimalna cena', 'Neyman - Pearson')
    title('Neuman - Pearson')   
    


%%

e1 = 0.00001;
e2 = 0.00001;

a = log(e2/(1-e1));
b = log((1 - e2)/e1);

N = 50;
figure()
for m = 1:N
    
    Sm = 0;
    n1 = 0;
    e1 = 0;
    Sm_niz1 = [];
    while (Sm > a && Sm < b)
        
        ind = randi(500);
        X = K1(:, ind);
        f11 = c1*exp(-0.5*(X-M1)'*inv(S1)*(X-M1));
        f12 = c2*exp(-0.5*(X-M2)'*inv(S2)*(X-M2));% Funkcije gustine verovatnoce
        f21 = c3*exp(-0.5*(X-M3)'*inv(S3)*(X-M3));
        f22 = c4*exp(-0.5*(X-M4)'*inv(S4)*(X-M4));
        f1 = 0.6*f11 + 0.4*f12;
        f2 = 0.3*f21 + 0.7*f22;
        
        h = log(f2) - log(f1);
        Sm = Sm +h;
        n1 = n1 + 1;
        Sm_niz1(n1) = Sm;
        
    end
    
    if Sm <= a
        plot(1:(n1), Sm_niz1, 'r')
        hold on
    else Sm >= b
        plot(1:n1, Sm_niz1, 'b--')
        hold on
        e1 = e1 + 1;
    end
    Sm = 0;
    n2 = 0;
    e2 = 0;
    Sm_niz2 = [];
    while (Sm > a && Sm < b)
        
        ind = randi(500);
        X = K2(:, ind);
        f11 = c1*exp(-0.5*(X-M1)'*inv(S1)*(X-M1));
        f12 = c2*exp(-0.5*(X-M2)'*inv(S2)*(X-M2));% Funkcije gustine verovatnoce
        f21 = c3*exp(-0.5*(X-M3)'*inv(S3)*(X-M3));
        f22 = c4*exp(-0.5*(X-M4)'*inv(S4)*(X-M4));
        f1 = 0.6*f11 + 0.4*f12;
        f2 = 0.3*f21 + 0.7*f22;
        
        h = log(f2) - log(f1);
        Sm = Sm +h;
        n2 = n2 + 1;
        Sm_niz2(n2) = Sm;
        
    end
    
    if Sm <= a
        plot(1:(n2), Sm_niz2, 'r--')
        hold on
        e2 = e2 + 1;
        
    
    else Sm >= b
        plot(1:(n2), Sm_niz2, 'b')
        hold on
    end
        
end
    
plot([1 6], [a a], 'm')
plot([1 6], [b b], 'c')
title('Waldov sekvencijalni test ako nam dolaze samo odbirci iz iste klase')



e1_niz = [0.0000001, 0.000001, 0.00001, 0.0001, 0.001, 0.01, 0.5];

for l = 1:length(e1_niz)
    e1 = e1_niz(l);
    e2 = e1;

    a = log(e2/(1-e1));
    b = log((1 - e2)/e1);

    N = 50;
    
    for m = 1:N

        
        n1 = 0;
        Sm = 0;
        
        while (Sm > a && Sm < b)

            ind = randi(500);
            X = K1(:, ind);
            f11 = c1*exp(-0.5*(X-M1)'*inv(S1)*(X-M1));
            f12 = c2*exp(-0.5*(X-M2)'*inv(S2)*(X-M2));% Funkcije gustine verovatnoce
            f21 = c3*exp(-0.5*(X-M3)'*inv(S3)*(X-M3));
            f22 = c4*exp(-0.5*(X-M4)'*inv(S4)*(X-M4));
            f1 = 0.6*f11 + 0.4*f12;
            f2 = 0.3*f21 + 0.7*f22;

            h = log(f2) - log(f1);
            Sm = Sm +h;
            n1 = n1 + 1;
            

        end
       
        
        broj_odb1(m) = n1;
       
       
     

    end

    
    greska1(l) = max(broj_odb1);
 

end

figure
semilogx(e1_niz, greska1 )
title('Zavisnost minimalnog broja odbiraka od greske tipa 1')


e2_niz = [0.0000001, 0.000001, 0.00001, 0.0001, 0.001, 0.01];
for l = 1:length(e2_niz)
    e2 = e2_niz(l);
    e1 = e2;

    a = log(e2/(1-e1));
    b = log((1 - e2)/e1);

    N = 50;
   
    for m = 1:N

        
        n2 = 0;
        Sm = 0;
       
        while (Sm > a && Sm < b)

            ind = randi(500);
            X = K2(:, ind);
            f11 = c1*exp(-0.5*(X-M1)'*inv(S1)*(X-M1));
            f12 = c2*exp(-0.5*(X-M2)'*inv(S2)*(X-M2));% Funkcije gustine verovatnoce
            f21 = c3*exp(-0.5*(X-M3)'*inv(S3)*(X-M3));
            f22 = c4*exp(-0.5*(X-M4)'*inv(S4)*(X-M4));
            f1 = 0.6*f11 + 0.4*f12;
            f2 = 0.3*f21 + 0.7*f22;

            h = log(f2) - log(f1);
            Sm = Sm +h;
            n2 = n2 + 1;
            
       
        end
        broj_odb2(m) = n2;
       
       
     

    end

    
    
    greska2(l) = max(broj_odb2);

end
figure
semilogx(e2_niz, greska2 )
title('Zavisnost minimalnog broja odbiraka od greske tipa 2')


%% Pokusaj

e1 = 0.00001;
e2 = 0.00001;

a = log(e2/(1-e1));
b = log((1 - e2)/e1);

N = 50;
figure()
K = [K1 K2];
for m = 1:N
    
    Sm = 0;
    n1 = 0;
    e1 = 0;
    Sm_niz1 = [];
    while (Sm > a && Sm < b)
        
        ind = randi(1000);
        X = K(:, ind);
        f11 = c1*exp(-0.5*(X-M1)'*inv(S1)*(X-M1));
        f12 = c2*exp(-0.5*(X-M2)'*inv(S2)*(X-M2));% Funkcije gustine verovatnoce
        f21 = c3*exp(-0.5*(X-M3)'*inv(S3)*(X-M3));
        f22 = c4*exp(-0.5*(X-M4)'*inv(S4)*(X-M4));
        f1 = 0.6*f11 + 0.4*f12;
        f2 = 0.3*f21 + 0.7*f22;
        
        h = log(f2) - log(f1);
        Sm = Sm +h;
        n1 = n1 + 1;
        Sm_niz1(n1) = Sm;
        
    end
    
    if Sm <= a
        if ind <= 500
            plot(1:(n1), Sm_niz1, 'r')
            hold on
        else 
            plot(1:(n1), Sm_niz1, 'r--')
            hold on
        end
    else Sm >= b
        if ind > 500
             plot(1:n1, Sm_niz1, 'b')
             hold on
        else
            plot(1:n1, Sm_niz1, 'b--')
            hold on
        end
            
    end
    
        
end
    
plot([1 9], [a a], 'm')
plot([1 9], [b b], 'c')
title('Wald-ov sekvencijalni test')
















