function f = fgv(x,m,s)


f = 2* pi* 1/sqrt(  det(s)) * exp(-0.5*(x - m)' * inv(s) * (x - m));

end