clear all
clc
close all

N = 500; % Odbirci svake od klasa
K = 4;

M1 = [0 0]'; S1 = [2 -0.5; -0.5 2];
M2 = [-5 8]'; S2 = [0.9 0.7; 0.7 0.9];
M3 = [10 7]'; S3 = [1 -0.5; -0.5 1];
M4 = [12 -2]'; S4 = [1 0.6; 0.6 1];


K1 = mvnrnd(M1,S1,N)';
K2 = mvnrnd(M2,S2,N)';
K3 = mvnrnd(M3,S3,N)';
K4 = mvnrnd(M4,S4,N)';

%%
Ntest = 10;
broj_iteracija = zeros(1,length(Ntest));
for w = 1:Ntest
    X = [K1 K2 K3 K4];

    indeksi = randperm(length(X));
    X = X(:,indeksi);
    labele = randi(K,[1, length(X)]);

    figure
    scatter(X(1, :), X(2, :), 10, labele, 'filled');
    hold on;
    % scatter(centroids(:, 1), centroids(:, 2), 100, 'k', 'filled');
    % hold off;
    title('Klasterizacija - inicijalizacija');
    xlabel('x1');
    ylabel('x2');


    

    M = zeros(2, K);
    P = zeros(1, K);
    S = zeros(2,2,K);

    for k = 1:K

       M(:,k) = mean(X(:,find(labele == k)),2);
       P(:,k) = sum(labele == k)/ length(labele);
       S(:,:,k) = cov((X(:,find(labele == k)))');

    end

    maxIter = 100;
    for iter = 1:maxIter
       labele_nove = zeros(1, length(X));
       for i = 1:length(X)

          for j = 1:K 
             %distance(j) = 0.5 * (X(:,i) - M(:,j))' * inv(S(:,:,j)) * (X(:,i) - M(:,j)) + 0.5 *log(det(S(:,:,j))) - log(P(j));
             distance(j) = sum((X(:,i) - M(:,j)).^2);
          end

          [m, ind] = min(distance);
          labele_nove(i) = ind;
       end





       if isequal(labele, labele_nove)
           broj_iteracija(w) = iter;
           break
       else
           labele = labele_nove;
       end 

        

       for k = 1:K

       M(:,k) = mean(X(:,find(labele == k)),2);
       P(:,k) = sum(labele == k)/ length(labele);
       S(:,:,k) = cov((X(:,find(labele == k)))');

       end

    end

    figure
    scatter(X(1, :), X(2, :), 10, labele, 'filled');
    hold on;
    % scatter(centroids(:, 1), centroids(:, 2), 100, 'k', 'filled');
    % hold off;
    title('Klasterizacija');
    xlabel('x1');
    ylabel('x2');
    
end  


figure
plot(1:Ntest, broj_iteracija)
title('Broj iteracija')
disp(['Prosecan broj iteracija je: ', num2str(mean(broj_iteracija))])

%% Metod maksimalne verodostojnosti
Ntest = 10;
broj_iteracija = zeros(1,length(Ntest));
for w = 1:Ntest

X = [K1 K2 K3 K4];

indeksi = randperm(length(X));
X = X(:,indeksi);
labele = randi(K,[1, length(X)]);

figure
scatter(X(1, :), X(2, :), 10, labele, 'filled');
hold on;
% scatter(centroids(:, 1), centroids(:, 2), 100, 'k', 'filled');
% hold off;
title('Klasterizacija - inicijalizacija');
xlabel('x1');
ylabel('x2');




M = zeros(2, K);
P = zeros(1, K);
S = zeros(2,2,K);

for k = 1:K

   M(:,k) = mean(X(:,find(labele == k)),2);
   P(:,k) = sum(labele == k)/ length(labele);
   S(:,:,k) = cov((X(:,find(labele == k)))');

end
N_ukupno = length(X)';
maxIter = 100;
for iter = 1:maxIter
   labele_nove = zeros(1, length(X));
   for i = 1:length(X)

      for j = 1:K 
         
         x = X(:,i);
         f(j) = 2 * pi * 1/sqrt( det(S(:,:,j))) * exp(-0.5*(x - M(:,j))' * inv(S(:,:,j)) * (x - M(:,j)));
        
      end
      f_ukupno = sum(f);
      q(:,i) = (P .* f)/f_ukupno;
      
      
   end

%    P = 1/N_ukupno * sum(q,2)';
%    M  = (X * q')./ (P*N_ukupno);
   for j = 1:K
        suma1 = 0;
        suma2 = 0;
        suma3 = 0;
            for i = 1:length(X)
                suma1 = suma1 + q(j,i) * (X(:,i) - M(:,j))*(X(:,i) - M(:,j))';
                suma2 = suma2 + q(j,i);
                suma3 = suma3 + q(j,i)* X(:,i);
            end
        P(:,j) = suma2/(N_ukupno);
        S(:,:,j) = suma1/(N_ukupno * P(:,j));
        M(:,j) = suma3/(N_ukupno * P(:,j));
        
   end
   
   for i = 1:length(X)

      for j = 1:K 
         %distance(j) = 0.5 * (X(:,i) - M(:,j))' * inv(S(:,:,j)) * (X(:,i) - M(:,j)) + 0.5 *log(det(S(:,:,j))) - log(P(j));
         %distance(j) = sum((X(:,i) - M(:,j)).^2);
         x = X(:,i);
         f(j) =  2*pi* 1/sqrt(det(S(:,:,j))) * exp(-0.5*(x - M(:,j))' * inv(S(:,:,j)) * (x - M(:,j)));
        
      end
      f_ukupno = sum(f);
      q_novo(:,i) = (P .* f)/f_ukupno;
      [m , indeks] = max(q_novo(:,i));
      labele_nove(i) = indeks;
     
       
      
   end
    
   
    if isequal(labele, labele_nove)
           broj_iteracija(w) = iter;
           break
       else
           labele = labele_nove;
       end 

 end



figure
scatter(X(1, :), X(2, :), 10, labele, 'filled');
hold on;
% scatter(centroids(:, 1), centroids(:, 2), 100, 'k', 'filled');
% hold off;
title('Klasterizacija');
xlabel('x1');
ylabel('x2');

end


figure
plot(1:Ntest, broj_iteracija)
title('Broj iteracija')
disp(['Prosecan broj iteracija je: ', num2str(mean(broj_iteracija))])


%% Nelinearno separabilne klase
K = 3;
N = 500;
X1 = zeros(2,N);
Y = zeros(2,N);
ro_1   = rand(1,N);
teta_1 = rand(1,N)*2*pi;
ro_2   = rand(1,N)+3;
teta_2 = rand(1,N)*2*pi;

X1(1,:) = ro_1.*cos(teta_1);
X1(2,:) = ro_1.*sin(teta_1);

Y(1,:) = ro_2.*cos(teta_2);
Y(2,:) = ro_2.*sin(teta_2);


f = [];
f_ukupno = [];
q = [];
q_novo = [];

Ntest = 10;
broj_iteracija = zeros(1,length(Ntest));
for w = 1:Ntest
    X = [X1 Y];

    indeksi = randperm(length(X));
    X = X(:,indeksi);
    labele = randi(K,[1, length(X)]);

    figure
    scatter(X(1, :), X(2, :), 10, labele, 'filled');
    hold on;
    % scatter(centroids(:, 1), centroids(:, 2), 100, 'k', 'filled');
    % hold off;
    title('Klasterizacija - inicijalizacija');
    xlabel('x1');
    ylabel('x2');


    

    M = zeros(2, K);
    P = zeros(1, K);
    S = zeros(2,2,K);

    for k = 1:K

       M(:,k) = mean(X(:,find(labele == k)),2);
       P(:,k) = sum(labele == k)/ length(labele);
       S(:,:,k) = cov((X(:,find(labele == k)))');

    end

    maxIter = 100;
    for iter = 1:maxIter
       labele_nove = zeros(1, length(X));
       for i = 1:length(X)

          for j = 1:K 
             distance(j) = 0.5 * (X(:,i) - M(:,j))' * inv(S(:,:,j)) * (X(:,i) - M(:,j)) + 0.5 *log(det(S(:,:,j))) - log(P(j));
             %distance(j) = sum((X(:,i) - M(:,j)).^2);
          end

          [m, ind] = min(distance);
          labele_nove(i) = ind;
       end





       if isequal(labele, labele_nove)
           broj_iteracija(w) = iter;
           break
       else
           labele = labele_nove;
       end 

        

       for k = 1:K

       M(:,k) = mean(X(:,find(labele == k)),2);
       P(:,k) = sum(labele == k)/ length(labele);
       S(:,:,k) = cov((X(:,find(labele == k)))');

       end

    end

    figure
    scatter(X(1, :), X(2, :), 10, labele, 'filled');
    hold on;
    % scatter(centroids(:, 1), centroids(:, 2), 100, 'k', 'filled');
    % hold off;
    title('Klasterizacija');
    xlabel('x1');
    ylabel('x2');
    
end  


figure
plot(1:Ntest, broj_iteracija)
title('Broj iteracija')
disp(['Prosecan broj iteracija je: ', num2str(mean(broj_iteracija))])